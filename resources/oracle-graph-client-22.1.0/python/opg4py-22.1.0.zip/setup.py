#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
"""OPG4Py package."""

from setuptools import setup

setup(name="opg4py",
      python_requires='>=3.6',
      version='22.1.0',
      description="A python client for PGQL on RDBMS",
      url='OPG4PY',
      platforms=['Linux x86_64'],
      license='OTN',
      long_description="""# OPG4PY Python client
This python package involves the main feature of PGQL on RDBMS APIS:

* Create Property Graph
* Drop Property Graph
* Execute Pgql queries
""",
      long_description_content_type="text/markdown",
      packages=['opg4py', 'opg4py.jars', 'opg4py.pgql', 'opg4py._adb', 'opg4py._utils'],
      package_data={'opg4py.jars': ['*.jar']},
      classifiers=["Programming Language :: Python :: 3"])
