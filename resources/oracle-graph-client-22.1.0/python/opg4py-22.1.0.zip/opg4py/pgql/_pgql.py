#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
from jnius import autoclass
from opg4py._utils.error_handling import java_handler
from ._pgql_connection import PgqlConnection

PoolDataSourceFactory = autoclass('oracle.ucp.jdbc.PoolDataSourceFactory')


def get_connection(usr, pwd, jdbc_url):
    """Get a DB connection.

    :param usr: the DB user
    :param pwd: the DB password
    :param jdbc_url: the DB jdbc url
    :return: A PgqlConnection
    """
    pds = java_handler(PoolDataSourceFactory.getPoolDataSource, [])

    pds.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource")
    pds.setURL(jdbc_url)
    pds.setUser(usr)
    pds.setPassword(pwd)

    conn = java_handler(pds.getConnection, [])
    conn.setAutoCommit(0)

    pgql_connection = PgqlConnection.get_connection(conn)
    return pgql_connection
