#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#

"""OPG4Py package."""

import jnius_config

# Jnius config should be done before importing jnius. So we do this now, before other imports.
if not jnius_config.vm_running:
    # opg4py only bundles a subset of the jars needed for pypgx, therefore we let pypgx configure jnius if possible
    try:
        import pypgx as pgx  # noqa: F401
    except ImportError:
        from ._utils import env_vars as _env_vars
        jnius_config.set_classpath(_env_vars.OPG_CLASSPATH)

from opg4py import pgql  # noqa: E402
from opg4py import adb  # noqa: E402

__all__ = ["pgql", "adb"]
