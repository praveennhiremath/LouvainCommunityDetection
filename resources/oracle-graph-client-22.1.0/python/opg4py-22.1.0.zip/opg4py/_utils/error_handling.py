#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
"""Tools for handling exceptions that happen in Java."""

from jnius.jnius import JavaException


def java_handler(callable, arguments):
    """Call `callable` with the given arguments.

    Raise a RuntimeError if something goes wrong on the Java side."""

    try:
        return callable(*arguments)
    except JavaException as e:
        message = str(e)
        stacktrace = getattr(e, 'stacktrace', None)
        if stacktrace is not None:
            message += "\nJava stack trace:\n"
            stacktrace_java = [
                ("    " + line if "Caused by" not in line else line) for line in stacktrace
            ]
            message += '\n'.join(stacktrace_java)
        raise RuntimeError(message) from None
