#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
from datetime import datetime
from jnius import autoclass

boolean = autoclass('java.lang.Boolean')
local_date = autoclass('java.time.LocalDate')
local_time = autoclass('java.time.LocalTime')
timestamp = autoclass('java.time.LocalDateTime')
time_with_timezone = autoclass('java.time.OffsetTime')
timestamp_with_timezone = autoclass('java.time.OffsetDateTime')


def convert_to_python_type(item, graph=None):
    if isinstance(item, boolean):
        return bool(item)
    elif isinstance(item, local_date):
        return datetime.strptime(item.toString(), '%Y-%m-%d').date()
    elif isinstance(item, local_time):
        # Format may or may not have milliseconds in the string. Test for both.
        try:
            return datetime.strptime(item.toString(), '%H:%M:%S.%f').time()
        except ValueError:
            pass
        try:
            return datetime.strptime(item.toString(), '%H:%M:%S').time()
        except ValueError:
            pass
        try:
            return datetime.strptime(item.toString(), '%H:%M').time()
        except ValueError:
            pass
        try:
            return datetime.strptime(item.toString(), '%H').time()
        except ValueError:
            raise ValueError(item.toString() + " cannot be parsed into datetime")
    elif isinstance(item, timestamp):
        # Format may or may not have milliseconds in the string. Test for both.
        try:
            return datetime.strptime(item.toString(), '%Y-%m-%dT%H:%M:%S.%f')
        except ValueError:
            pass
        try:
            return datetime.strptime(item.toString(), '%Y-%m-%dT%H:%M:%S')
        except ValueError:
            pass
        try:
            return datetime.strptime(item.toString(), '%Y-%m-%dT%H:%M')
        except ValueError:
            pass
        try:
            return datetime.strptime(item.toString(), '%Y-%m-%dT%H')
        except ValueError:
            raise ValueError(item.toString() + " cannot be parsed into datetime")
    elif isinstance(item, time_with_timezone):
        # Adjust timezone to be readable by .strptime()
        item_str = item.toString()
        if item_str[-1] == 'Z':
            item_str = item_str[:-1] + '+0000'
        else:
            item_str = item_str[:-3] + item_str[-2:]
        # Format may or may not have milliseconds in the string. Test for both.
        try:
            return datetime.strptime(item_str, '%H:%M:%S.%f%z').timetz()
        except ValueError:
            pass
        try:
            return datetime.strptime(item_str, '%H:%M:%S%z').timetz()
        except ValueError:
            pass
        try:
            return datetime.strptime(item_str, '%H:%M%z').timetz()
        except ValueError:
            pass
        try:
            return datetime.strptime(item_str, '%H%z').timetz()
        except ValueError:
            raise ValueError(item.toString() + " cannot be parsed into datetime")
    elif isinstance(item, timestamp_with_timezone):
        # Adjust timezone to be readable by .strptime()
        item_str = item.toString()
        if item_str[-1] == 'Z':
            item_str = item_str[:-1] + '+0000'
        else:
            item_str = item_str[:-3] + item_str[-2:]
        # Format may or may not have milliseconds in the string. Test for both.
        try:
            return datetime.strptime(item_str, '%Y-%m-%dT%H:%M:%S.%f%z')
        except ValueError:
            pass
        try:
            return datetime.strptime(item_str, '%Y-%m-%dT%H:%M:%S%z')
        except ValueError:
            pass
        try:
            return datetime.strptime(item_str, '%Y-%m-%dT%H:%M%z')
        except ValueError:
            pass
        try:
            return datetime.strptime(item_str, '%Y-%m-%dT%H%z')
        except ValueError:
            raise ValueError(item.toString() + " cannot be parsed into datetime")
    else:
        return item
