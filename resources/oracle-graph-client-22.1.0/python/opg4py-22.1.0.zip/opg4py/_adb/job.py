#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
from jnius import autoclass
from opg4py._utils.error_handling import java_handler

JavaJob = autoclass('oracle.pg.rdbms.Job')


class Job:
    def __init__(self, javaJob):
        self.javaJob = javaJob

    def get_id(self):
        return self.javaJob.getId()

    def get_name(self):
        return self.javaJob.getName()

    def get_description(self):
        return self.javaJob.getDescription()

    def get_type(self):
        return self.javaJob.getType()

    def get_status(self):
        return self.javaJob.getStatus()

    def get_created_by(self):
        return self.javaJob.getCreatedBy()

    def get_error(self):
        return self.javaJob.getError()

    def get_logs(self):
        logs = []
        for entry in java_handler(self.javaJob.getLogEntries, []):
            item = {
                'timestamp': entry.getTimestamp(),
                'message': entry.getMessage()
            }
            logs.append(item)
        return logs

    def poll(self):
        java_handler(self.javaJob.poll, [])
        return self

    def get(self):
        java_handler(self.javaJob.get, [])

    def is_done(self):
        return java_handler(self.javaJob.isDone, [])

    def is_cancelled(self):
        return java_handler(self.javaJob.isCancelled, [])

    def is_completed_exceptionally(self):
        return java_handler(self.javaJob.isCancelled, [])
