Getting Started
===============

.. toctree::
   :maxdepth: 2

   overview
   install
   build
   cythonize
