import cheese

def report_cheese(name):
    print("Found cheese: " + name)

cheese.find(report_cheese)


